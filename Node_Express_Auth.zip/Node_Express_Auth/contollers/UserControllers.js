const { response } = require('express')
const { builtinModules } = require('module')
const User = require('../models/User')

// show list of user

const index = (req, res, next) => {
    User.find()
    .then(response =>{
        res.json({
            response
        })
    })
    .catch(error => {
        res.json({
            message: 'An error occured!'
        })
    })
}

// show user by userID

const show = (req, res, next) => {
    let userID = req.body.userID
    User.findById(userID)
    .then(response => {
        res.json({
            response
        })
    })
    .catch(error => {
        res.json({
            message: 'An error occured!'
        })
    })
}

// store new user details

const store = (req, res, next) => {
    let user = new User({
        name: req.body.name,
        email: req.body.email,
        password: req.body.password,
        permission: req.body.permission
    })

    user.save()
    .then(response => {
        res.json({
            message: 'user saved successfully!'
        })
    })
    .catch(error => {
        res.json({
            message: 'an error occured'
        })
    })
}

// update user

const update = (req, res, next) => {
    let userID = req.body.userID

    let updatedData = {
        name: req.body.name,
        email: req.body.email,
        password: req.body.password,
        permission: req.body.permission
    }

    User.findByIdAndUpdate(userID, { $set: updatedData} )
    .then(() =>{
        res.json({
            message: 'User data updated!'
        })
    })
    .catch(error => {
        res.json({
            message: 'an error occoured!'
        })
    })
}

// delete user

const destroy = (req, res, next) => {
    let userID = req.body.userID
    User.findByIdAndRemove(userID)
    .then(() => {
        res.json({
            message: 'User deletion done!'
        })
    })
    .catch(error => {
        res.json({
            message: 'an error occured!'
        })
    })
}


module.exports = {
    index, show, store, update, destroy
}