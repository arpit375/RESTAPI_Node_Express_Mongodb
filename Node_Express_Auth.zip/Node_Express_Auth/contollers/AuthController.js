const User_auth = require('../models/Auth_model')
const bcrypt = require('bcryptjs')
const jwt = require('jsonwebtoken')


// registration function
const register = (req, res, next) => {
    bcrypt.hash(req.body.password, 10, function(err, hashedPass) {
        if(err) {
            res.json({
                error: err
            })
        }

        let user = new User_auth ({
            name: req.body.name,
            email: req.body.email,
            password: hashedPass,
            permission: req.body.permission
        })
        user.save()
        .then(user => {
            res.json({
                message: 'User registered sucessfully!'
            })
        })
        .catch(error => {
            res.json({
                message: 'An error occured!'
            })
        })
    })

}

// login  function
const login = (req, res, next) => {
    var username = req.body.username
    var password = req.body.password

    User_auth.findOne({ email:username })
    .then(user => {
        if(user){
            bcrypt.compare(password, user.password, function(err, result){
                if(err) {
                    res.json({
                        error: err
                    })
                }
                if(result){
                    let token = jwt.sign({name: user.name}, 'SecretValue', { expiresIn: '1h'})
                    res.json({
                        message: 'Login Success!',
                        token
                    })
                }
                else{
                    res.json({
                        message: 'Password does not match!'
                    })
                }
            })

        }
        else{
            res.json({
                message: 'No user found!'
            })
        }
    })
}

module.exports = {
    register, login
}