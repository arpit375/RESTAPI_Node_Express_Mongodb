const express = require('express')
const router = express.Router()

const UserControllers = require('../contollers/UserControllers')

router.get('/', UserControllers.index)
router.post('/show', UserControllers.show)
router.post('/store', UserControllers.store)
router.post('/update', UserControllers.update)
router.post('/delete', UserControllers.destroy)

module.exports = router